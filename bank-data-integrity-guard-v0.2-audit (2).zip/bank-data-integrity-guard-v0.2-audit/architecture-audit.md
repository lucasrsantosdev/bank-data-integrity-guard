
# AEGISBANK - AUDITORIA INVESTIGATIVA V0.1
# Execucao na pasta externa do projeto
# Somente leitura do codigo; gera relatorios locais

$ErrorActionPreference = "Stop"

$ProjectRoot = (Get-Location).Path

# Detectar a pasta interna do projeto
if (-not (Test-Path (Join-Path $ProjectRoot "pyproject.toml"))) {
    $candidate = Join-Path $ProjectRoot "bank-data-integrity-guard"
    if (Test-Path (Join-Path $candidate "pyproject.toml")) {
        $ProjectRoot = $candidate
    }
}

if (-not (Test-Path (Join-Path $ProjectRoot "pyproject.toml"))) {
    throw "Projeto nao encontrado. Abra a pasta correta."
}

$AuditDir = Join-Path $ProjectRoot "artifacts\audit"
New-Item -ItemType Directory -Force -Path $AuditDir | Out-Null

$Results = [System.Collections.Generic.List[object]]::new()

function Add-Check {
    param(
        [string]$Area,
        [string]$Item,
        [string]$Status,
        [string]$Detail
    )

    $Results.Add([PSCustomObject]@{
        Area   = $Area
        Item   = $Item
        Status = $Status
        Detail = $Detail
    })
}

Write-Host "`n=== AEGISBANK - AUDITORIA ===" -ForegroundColor Cyan
Write-Host "Projeto: $ProjectRoot"

# 1 - Estrutura
$required = @(
    "README.md",
    "pyproject.toml",
    "src\bankguard\core.py",
    "src\bankguard\evidence.py",
    "src\bankguard\cli.py",
    "tests\test_core.py",
    "tests\test_evidence.py",
    "examples\before.csv",
    "examples\after.csv",
    "docs\methodology.md",
    "docs\security.md",
    "docs\roadmap.md"
)

foreach ($file in $required) {
    $exists = Test-Path (Join-Path $ProjectRoot $file)
    $status = if ($exists) { "PASS" } else { "FAIL" }
    Add-Check "Estrutura" $file $status "Arquivo obrigatorio"
}

# 2 - Inventario do codigo
$pythonFiles = @(
    Get-ChildItem -Path $ProjectRoot -Filter "*.py" `
        -Recurse -File |
    Where-Object {
        $_.FullName -notmatch '\\(\.venv|venv|__pycache__|\.git)\\'
    }
)

foreach ($file in $pythonFiles) {
    $relative = [IO.Path]::GetRelativePath(
        $ProjectRoot, $file.FullName
    )

    $hash = (Get-FileHash -Path $file.FullName -Algorithm SHA256).Hash

    Add-Check "Python" $relative "PASS" "SHA256=$hash"
}

# 3 - Mapeamento de capacidades
$patterns = [ordered]@{
    "Comparacao"       = 'compare|diff|changed'
    "Inclusao"         = 'insert|added|created'
    "Exclusao"         = 'delete|removed|missing'
    "SHA256"           = 'sha256'
    "HMAC"             = 'hmac'
    "Snapshot"         = 'snapshot'
    "Schema"           = 'schema|columns|dtype'
    "Banco SQL"        = 'sqlalchemy|psycopg|pyodbc'
    "Spark"            = 'pyspark|spark'
    "Kafka"            = 'kafka'
    "Airflow"          = 'airflow'
    "CDC"              = 'change.data.capture|debezium'
    "API"              = 'requests|httpx|fastapi'
    "Camadas Medalhao" = 'bronze|silver|gold|raw'
}

$sourceDir = Join-Path $ProjectRoot "src"

foreach ($capability in $patterns.Keys) {
    $matches = @()

    if (Test-Path $sourceDir) {
        $matches = @(
            Get-ChildItem $sourceDir -Filter "*.py" -Recurse -File |
            Select-String -Pattern $patterns[$capability]
        )
    }

    $status = if ($matches.Count -gt 0) { "FOUND" } else { "NOT_FOUND" }

    Add-Check "Capacidade" $capability $status `
        "Ocorrencias no codigo: $($matches.Count)"
}

# 4 - Sintaxe Python
$python = Get-Command python -ErrorAction SilentlyContinue

if ($python) {
    Push-Location $ProjectRoot
    try {
        $env:PYTHONDONTWRITEBYTECODE = "1"

        $syntaxScript = @'
import ast
import pathlib
import sys

root = pathlib.Path("src")
errors = []

for path in root.rglob("*.py"):
    try:
        ast.parse(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{path}: {exc}")

for error in errors:
    print(error)

sys.exit(1 if errors else 0)
'@

        $syntaxScript | python -
        $syntaxExit = $LASTEXITCODE

        $syntaxStatus = if ($syntaxExit -eq 0) { "PASS" } else { "FAIL" }
        Add-Check "Python" "Sintaxe AST" $syntaxStatus `
            "Codigo de saida: $syntaxExit"

        # 5 - Testes automatizados
        $testLog = Join-Path $AuditDir "unittest-output.txt"

        $testOutput = & python -m unittest discover -s tests -v 2>&1
        $testExit = $LASTEXITCODE

        $testOutput | Out-File $testLog -Encoding utf8

        $testStatus = if ($testExit -eq 0) { "PASS" } else { "FAIL" }

        Add-Check "Testes" "unittest discover" $testStatus `
            "Codigo de saida: $testExit"
    }
    finally {
        Pop-Location
    }
}
else {
    Add-Check "Ambiente" "Python" "WARN" "Python nao encontrado"
}

# 6 - Git
Push-Location $ProjectRoot
try {
    $git = Get-Command git -ErrorAction SilentlyContinue

    if ($git) {
        git rev-parse --is-inside-work-tree 2>$null | Out-Null

        if ($LASTEXITCODE -eq 0) {
            $gitStatus = git status --short

            Add-Check "Git" "Repositorio" "PASS" `
                "Repositorio Git inicializado"

            $gitStatus | Out-File `
                (Join-Path $AuditDir "git-status.txt") -Encoding utf8
        }
        else {
            Add-Check "Git" "Repositorio" "WARN" `
                "Git ainda nao inicializado"
        }
    }
    else {
        Add-Check "Git" "Instalacao" "WARN" "Git nao encontrado"
    }
}
finally {
    Pop-Location
}

# 7 - Verificacao basica de nomes sensiveis
$sensitiveNames = @(
    ".env",
    "*.pem",
    "*.pfx",
    "*.key",
    "*credentials*",
    "*secret*"
)

foreach ($pattern in $sensitiveNames) {
    $found = @(
        Get-ChildItem $ProjectRoot -Recurse -File -Force `
            -Filter $pattern -ErrorAction SilentlyContinue |
        Where-Object {
            $_.FullName -notmatch '\\(\.git|\.venv|venv|__pycache__)\\'
        }
    )

    if ($found.Count -gt 0) {
        Add-Check "Seguranca" $pattern "WARN" `
            "Arquivos potencialmente sensiveis: $($found.Count)"
    }
}

# 8 - Relatorios
$jsonPath = Join-Path $AuditDir "architecture-audit.json"
$mdPath = Join-Path $AuditDir "architecture-audit.md"

$Results | ConvertTo-Json -Depth 6 |
    Out-File $jsonPath -Encoding utf8

$lines = @(
    "# AegisBank - Auditoria Investigativa",
    "",
    "Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
    "",
    "## Resultados",
    "",
    "| Area | Item | Status | Detalhe |",
    "|---|---|---|---|"
)

foreach ($result in $Results) {
    $detail = ($result.Detail -replace '\|', '/')
    $lines += "| $($result.Area) | $($result.Item) | $($result.Status) | $detail |"
}

$lines += ""
$lines += "## Interpretacao"
$lines += ""
$lines += "FOUND significa apenas ocorrencia textual no codigo."
$lines += "Nao comprova funcionalidade implementada."
$lines += "PASS em sintaxe e testes nao comprova seguranca bancaria."
$lines += "Esta auditoria nao acessa bancos reais."

$lines | Out-File $mdPath -Encoding utf8

Write-Host "`n=== RESUMO ===" -ForegroundColor Cyan

$Results |
    Group-Object Status |
    Select-Object Name, Count |
    Format-Table -AutoSize

Write-Host "Relatorio: $mdPath" -ForegroundColor Green
Write-Host "JSON: $jsonPath" -ForegroundColor Green
Write-Host "`nAuditoria concluida."
